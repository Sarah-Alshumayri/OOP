/**
 * Lab 2 Problem 5
 * @author (Passent Elkafrawy)
 * @version (30/1/2023)
 * Students : Leen Sharab-Ameera Attiah- Sarah Alshumayri
 * Student ID: S21107195-S21107316-S20106125
 */




import java.util.Scanner;

public class Main {
  // Function to validate credit card number
  public static void validateCard(String input) {
    // Check if the length of the credit card number is either 13 or 16
    if (input.length() != 13 && input.length() != 16) {
      System.out.println("->Incorrect length");
    }

    // Check if the credit card number begins with 4, 5, 37, or 6
    if (!input.startsWith("4") || !input.startsWith("5") && !input.startsWith("37") && !input.startsWith("6")) {
      System.out.println("->Incorrect starting digits");

    }

    // Array to store individual digits of the credit card number
    int[] creditnum = new int[input.length()];
    
    // Loop to convert each character of the input string to an integer
    for(int i=0; i< input.length();i++){
        creditnum[i] = Integer.parseInt(input.substring(i,i+1));
    }
    
    // Loop to apply the Luhn algorithm for validation
    for(int i= (creditnum.length - 2) ; i>=0; i-=2){
        int value = creditnum[i];
        value = value * 2;
        if(value > 9){
            value = value % 10 +1;
        }
        creditnum[i] = value;
    }
    
    // Sum up all the digits of the credit card number
    int total = 0;
    for (int i=0; i<creditnum.length;i++){
        total+=creditnum[i];
    }
    
    // Check if the sum is divisible by 10
    if (total % 10 ==0){
        System.out.print("Valid Card!!");
    }
    else{
        System.out.print("Invalid Card!!");
    }
  }

  public static void main(String[] args) {
    Scanner numberinput = new Scanner(System.in);
    System.out.println("Enter a credit card number as a long integer: ");
    long cardnumber = numberinput.nextLong();
    
    // Convert the `long` `cardnumber` to a `String`
    String cardnumberString = Long.toString(cardnumber);
    
    // Call the `validateCard` function with the entered credit card number as a string
    validateCard(cardnumberString);
  }
}
