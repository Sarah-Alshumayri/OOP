package Lab2;
import java.util.Scanner;

public class lab2_Problem1 {

	public static void main(String[] args) {
		Scanner input = new Scanner (System.in);
		
		//asking the user for the x and y coordinates
		System.out.println("Enter a point with two coordinates: "); 
		
		System.out.print("x = ");
		double x = input.nextDouble(); //x coordinate
		
		System.out.print("y = ");
		double y = input.nextDouble(); //y coordinate

		//calculating the horizontal distance between the point and x axis 
		double hDistance = Math.pow(x * x, 0.5); 
		
		//calculating the vertical distance between the point and y axis 
		double vDistance = Math.pow(y * y, 0.5); 
		
		/* checking if the point is inside the rectangle by checking if the hDistance is less than or equal 
		to 5 and the vDistance is less than or equal to 2.5 then it's inside the rectangle */
		if (hDistance <= 5 && vDistance <= 2.5) { 
			
			System.out.println("Point (" + x + ", " + y + ") is in the rectangle");
		}
		else { //if the point is outside the rectangle
			System.out.println("Point (" + x + ", " + y + ") is not in the rectangle");
		}
	}
}
