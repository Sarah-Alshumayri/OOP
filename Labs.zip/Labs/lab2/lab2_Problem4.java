/**
 * Lab 1 Problem 4
 * @author (Passent Elkafrawy)
 * @version (31/1/2023)
 * Student 1: Sarah Alshumayri S20106125
 * Student 2: Ameera Attiah S21107316	 
 * Student 3: Leen Sharab S21107195 
 */
package Lab2;

import java.util.Scanner;

		public class lab2_Problem4 {
		  public static void main(String[] args) {
		    Scanner input = new Scanner(System.in);
		    int max = 0; // variable to store the current largest number
		    int count = 0; // variable to store the occurrence count of the largest number
		    int number; // variable to store the current input number
		    
		    // Continuously read input numbers until 0 is entered
		    System.out.print("Enter integers (input ends with 0): ");
		    number = input.nextInt();

		    while (number != 0) {
		    // If the current input number is equal to the current largest number

		      if (number == max) {
		        count++; // increment the occurrence count
		        
		      // If the current input number is greater than the current largest number
		      } else if (number > max) {
		          max = number; // assign the current input number as the new largest number
		          count = 1; // reset the occurrence count to 1
		      }
		      number = input.nextInt();
		    }

		    System.out.println("The largest number is " + max);
		    System.out.println("The occurrence count of the largest number is " + count);
		  }
		}
