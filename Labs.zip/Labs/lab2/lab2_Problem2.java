package Lab2;
import java.util.Scanner;

public class lab2_Problem2 {

	public static void main(String[] args) {
		
		//asking the user for the numerator
		System.out.print("Enter the Numerator: ");
		Scanner input1 = new Scanner (System.in);
		int numerator = input1.nextInt() ;
		
		//asking the user for the denominator
		System.out.print("Enter the Denominator: ");
		Scanner input2 = new Scanner (System.in);
		int denominator = input2.nextInt() ;
		
		if (numerator > denominator ) { //checking if the numerator is greater than the denominator to see if the fraction is proper or improper
			
			if (numerator % denominator == 0) { //checking if the improper fraction is a whole number or a mixed fraction
				
				System.out.print(numerator + " / "+ denominator + " is a improper fraction and it can be reduced to " + numerator/denominator);
			}
			else {
				int a = numerator % denominator; //to find the numerator of the mixed fraction
				int b = numerator / denominator; //to find the denominator of the mixed fraction
				System.out.print(numerator + " / "+ denominator + " is a improper fraction and its mixed fraction " + b + " + "+  a + " / "+ denominator );
			}
		}
		else {
			System.out.print(numerator + " / "+ denominator + " is a proper fraction");
		}
	}
}
