/**
 * 
 */
/**
 * @author samal
 *
 */
module Lab1 {
}